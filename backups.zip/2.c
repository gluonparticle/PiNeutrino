#include <stdio.h>
#include <omp.h>
int main() {
    int n;
    printf("Enter number of iterations: ");
    scanf("%d", &n);
    #pragma omp parallel for schedule(static, 2)
    for (int i = 0; i < n; i++) {
        int tid = omp_get_thread_num();
        printf("Thread %d : Iteration %d\n", tid, i);
    }
    return 0;
}

/*
Compilation & Execution Instructions:
gcc -fopenmp 2.c -o p2
./p2
*/
